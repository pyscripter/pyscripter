
Patches for TB2K v2.1.8 and TBX v2.1.beta.

Requirements
~~~~~~~~~~~~
- Jordan Russell's Toolbar2000 v2.1.8
  http://www.jrsoftware.org
- Alex Denisov's TBX v2.1.beta
  http://g32.org

What's new?
~~~~~~~~~~~
Changes made by Robert Lee:
1. Changed the compression to zip.
2. Removed the vbs file.
3. Updated Delphi 7 and Delphi 2005 runtime packages to be runtime only.
4. Added patching bat files.
5. Added Delphi 2006 packages and BDSProj files.
6. Added support for C++Builder 2006.
7. Renamed DropdownCombo to DropDownCombo in TBXDkPanels.pas, need for C++Builder.
8. Renamed DropdownMenu to DropDownMenu in TBXDkPanels.pas, needed for C++Builder.
9. Fixed TTBXComboBoxItem bug, when AutoComplete is set to false the TTBXComboBoxItem still autocompletes the text.
10. Fixed menu animation bug, the menus were animated even when the animation was disabled in the Desktop settings.

The third edition:
1. Included TBX Delphi 2005 packages.
2. Fixed TBX GradFill function (Windows9x has bug in
   GradientFill function - not fill window nonclient area).
3. TBX BrushedFill and GradFill functions now allocate
   resources only on demand (program starts a bit faster).
4. Now drawn Scrollbar's thumb gripper in TBXComboBoxItem,
   TBXStringList and TBXUndoList (WindowsXP).
5. Added event properties to TBXEditItem:
     OnKeyDown, OnKeyPress, OnKeyUp.
6. Fix: TTBXSubMenuItem.ToolBoxPopup property was ignored.
7. Fix: Popups on MultiMonitors systems appears only on main monitor.
8. Fix: Access violation in TBXComboBoxItem, if quickly clicks on
   popupped list.
9. New functions in TBXUtil: EllipseEx, RectangleEx.
10. Now mouse wheel scrolls long menu/popup menu.
11. Last improvements from TB2k CVS - in ItemDesignEditor.
12. Internal improvements.
13. The script of installation is corrected (thanks to Dmitry Kann).
14. Excluded patch for Office2003 theme.
15. Included license.

The second edition:
1. Added new class TTBXMenuAnimation and TBXMenuAnimation global variable.
   TBXMenuAnimation.AnimationMode lets you change the mode of menu
   animation (if it's supported by operational system):
   amNone, amSysDefault, amRandom, amUnfold, amSlide, amFade.
   For query accessible modes use TBXMenuAnimation.AvailableModes property.
2. Now no delaying on the first menu show (Windows 2000 and later).
3. Fix: The long pop-up menu does not cover Windows taskbar.
4. Property Action is added to:
   TTBXLabel, TTBXLink, TTBXButton, TTBXCheckBox, TTBXRadioButton
   (thanks to Francisco Duenas).
5. Fix: System brushes do not leave any more in TBXUtils.
   Though system does not delete them, but... (thanks to Hp).
6. Included fixes from SpTBX by Robert Lee:
   o TTBXDockablePanel now inherited from TTBXCustomDockablePanel.
   o Fixed editors bug, the editors autocomplete now not case sensitive
     (in TTBXEditItem. HandleEditChange).
   o Fixed TBXDropDownItem and TBXComboBoxItem bugs, the pop-up list
     should be closed when F4 is pressed.
   o Fixed TBXComboBoxItem bug, the ComboBox did not check the ItemIndex
     bounds when pressing Up or Down keys.
   o Published (in protected section) TTBXCustomListViewer's FOffset and
     FVisibleItems members (properties Offset and VisibleItems).

The first edition:
1. TBX now compatible with TB2k v2.1.6.
2. Added TTBXPopup.PopupEx function introdused in TB2k 2.1.6.
3. Added TTBXDockablePanel vertical/horizontal resize/split cursor's
   property.
4. New function RoundRectEx in TBXUtil.
5. AluminumTheme now paint RadioItem, increased menuitem text left margin.
6. Office2003Theme now paint RadioItem.
7. Fixed paint of scroll arrows in OfficeXPTheme and Office2003Theme.

How to install?
~~~~~~~~~~~~~~~
Remove or copy to other folder files of old versions TB2 and TBX.
Unzip TB2 v2.1.8 and TBX v2.1.beta.
For patch TB2 and TBX simply launch "_Patch TB2k & TBX.vbs" script,
and choose TB2\Source and TBX folders.
For details on installing TB2 and TBX in Delphi, refer to the
TB2 and TBX documentation. (Note: At TBX installation miss steps 2 and 3).

--------------------------------------------------------------------------
Vladimir Bochkarev <boxa@mail.ru>