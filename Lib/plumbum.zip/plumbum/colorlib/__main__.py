"""
This is provided as a quick way to recover your terminal. Simply run
``python -m plumbum.colorlib``
to recover terminal color.
"""

from __future__ import absolute_import

from . import main

main()
