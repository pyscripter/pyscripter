Office2003 Theme for TBX v2.1
Copyright (c) Yury Plashenkov (Sep. 2005)
================================================================================

This theme recreates the toolbar and menu appearance introduced in
Microsoft Office2003.

To make Office2003 theme available at runtime, include theme unit
"TBXOffice2003Theme" into the "uses" clause. To make theme active, either use
the TTBXSwitcher component, or TBXSetTheme function.

To use semitransparent PNG images in your application, use PngComponents package
You can download it from http://www.thany.org/
     
Changes: 
  1. MDIAreaColor property added
  2. OnSetupColorCache event added
  3. PNGImageList removed (use TPngImageList from PngComponents instead)
  4. Added code to support "radio" items (Toolbar2000 version 2.1.6)
  5. Small bugs fixed
     
Thanks Roy Magne Klever for his site
Thanks guys from Microsoft for their theme :)

Good luck
     
================================================================================
mailto:plashenkov@mail.ru
