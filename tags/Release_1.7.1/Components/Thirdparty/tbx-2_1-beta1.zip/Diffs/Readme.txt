This directory contains files required for patching Toolbar 2000 
sources to make them compatible with TBX.